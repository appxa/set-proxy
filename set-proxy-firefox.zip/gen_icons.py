"""Generate square toolbar icons for the Proxy Switch extension, styled
like Firefox's built-in toolbar icons: a simple flat glyph filling most
of the square. Blue when the proxy is off, green when it's active --
same glyph, just a recolor, no badge.
"""
from PIL import Image, ImageDraw

FX_BLUE = (10, 132, 255, 255)   # Firefox accent blue (#0a84ff), off/inactive
GREEN = (48, 209, 88, 255)      # active

sizes = [16, 32, 48, 96, 128]


def draw_glyph(d, size, color):
    """A simple globe/proxy-node glyph: circle outline + crossing lines,
    like a minimalist network/globe icon -- reads clearly at 16px."""
    cx = cy = size / 2
    r = size * 0.40
    stroke = max(1, round(size * 0.075))

    # outer circle (globe)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=stroke)

    # horizontal meridian
    d.line([cx - r, cy, cx + r, cy], fill=color, width=stroke)

    # vertical "squeeze" meridian (ellipse) to suggest a globe
    d.ellipse([cx - r * 0.45, cy - r, cx + r * 0.45, cy + r], outline=color, width=stroke)


for size in sizes:
    off = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw_glyph(ImageDraw.Draw(off), size, FX_BLUE)
    off.save(f"/home/pc/Downloads/set-proxy/icons/icon-off-{size}.png")

    on = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw_glyph(ImageDraw.Draw(on), size, GREEN)
    on.save(f"/home/pc/Downloads/set-proxy/icons/icon-on-{size}.png")

print("done")
