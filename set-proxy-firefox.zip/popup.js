"use strict";

const $ = (id) => document.getElementById(id);
let state = { proxies: [], activeId: null, proxyOn: false, pingResults: {} };

function send(msg) {
  return browser.runtime.sendMessage(msg);
}

function setMsg(el, text, kind) {
  el.textContent = text || "";
  el.classList.remove("ok", "bad");
  if (kind) el.classList.add(kind);
}

function shortErr(e) {
  return e ? e.split(" ")[0] : "failed";
}

// ---- add form ----
function currentFormCfg() {
  return {
    type: $("proxyType").value,
    host: $("proxyHost").value.trim(),
    port: $("proxyPort").value.trim(),
  };
}

function clearForm() {
  $("proxyType").value = "socks";
  $("proxyHost").value = "";
  $("proxyPort").value = "";
}

$("proxyAdd").onclick = async () => {
  const cfg = currentFormCfg();
  if (!cfg.host || !cfg.port) {
    return setMsg($("proxyMsg"), "Host and port required", "bad");
  }
  state = await send({ cmd: "addProxy", cfg });
  clearForm();
  setMsg($("proxyMsg"), "Added.", "ok");
  render();
};

$("proxyToggle").onchange = async (e) => {
  state = await send({ cmd: "setProxyOn", on: e.target.checked });
  if (state.proxyOn) refreshActivePing();
  else $("activePing").textContent = "";
};

async function refreshActivePing() {
  const el = $("activePing");
  if (!state.proxyOn || !state.activeId) { el.textContent = ""; el.className = "active-ping"; return; }
  el.textContent = "...";
  el.className = "active-ping";
  const r = await send({ cmd: "testProxy", id: state.activeId });
  if (!state.proxyOn) { el.textContent = ""; return; }
  if (r.ok) { el.textContent = r.ms + " ms"; el.className = "active-ping ok"; }
  else { el.textContent = shortErr(r.error); el.className = "active-ping bad"; }
}

$("freeProxy").onclick = () => browser.tabs.create({ url: "freeproxy.html" });

// ---- list ----
function labelFor(p) {
  return (p.country ? p.country + " " : "") + p.host + ":" + p.port;
}

function render() {
  $("proxyToggle").checked = !!state.proxyOn;
  if (state.proxyOn && state.activeId) refreshActivePing();
  else $("activePing").textContent = "";

  const list = $("list");
  list.innerHTML = "";

  if (!state.proxies.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "No proxies added yet.";
    list.appendChild(empty);
    return;
  }

  for (const p of state.proxies) {
    const div = document.createElement("div");
    div.className = "proxy" + (p.id === state.activeId ? " active" : "");

    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "activeProxy";
    radio.checked = p.id === state.activeId;
    radio.onchange = async () => {
      state = await send({ cmd: "selectProxy", id: p.id });
      render();
    };

    const type = document.createElement("span");
    type.className = "type";
    type.textContent = p.type === "socks" ? "socks5" : p.type;

    const ping = document.createElement("span");
    ping.className = "ping";
    ping.id = "ping-" + p.id;
    const previousPing = state.pingResults && state.pingResults[p.id];
    if (previousPing) {
      ping.textContent = previousPing.ok ? previousPing.ms + " ms" : shortErr(previousPing.error);
      ping.classList.add(previousPing.ok ? "ok" : "bad");
    }

    const addr = document.createElement("span");
    addr.className = "addr";
    addr.textContent = labelFor(p);
    addr.title = labelFor(p);

    const testBtn = document.createElement("button");
    testBtn.textContent = "Test";
    testBtn.onclick = async () => {
      testBtn.textContent = "...";
      ping.textContent = "";
      ping.classList.remove("ok", "bad");
      const r = await send({ cmd: "testProxy", id: p.id });
      testBtn.textContent = "Test";
      if (r.ok) {
        ping.textContent = r.ms + " ms";
        ping.classList.add("ok");
      } else {
        ping.textContent = shortErr(r.error);
        ping.classList.add("bad");
      }
    };

    const delBtn = document.createElement("button");
    delBtn.textContent = "\u00d7";
    delBtn.onclick = async () => {
      state = await send({ cmd: "removeProxy", id: p.id });
      render();
    };

    div.append(radio, type, addr, ping, testBtn, delBtn);
    list.appendChild(div);
  }
}

// ---- test all ----
$("testAll").onclick = async () => {
  const btn = $("testAll");
  btn.disabled = true;
  btn.textContent = "...";
  try {
    await Promise.all(
      state.proxies.map(async (p) => {
        const ping = $("ping-" + p.id);
        if (!ping) return;
        ping.textContent = "...";
        ping.classList.remove("ok", "bad");
        const r = await send({ cmd: "testProxy", id: p.id });
        if (r.ok) {
          ping.textContent = r.ms + " ms";
          ping.classList.add("ok");
        } else {
          ping.textContent = shortErr(r.error);
          ping.classList.add("bad");
        }
      })
    );
  } finally {
    btn.disabled = false;
    btn.textContent = "Test all";
  }
};

// ---- delete all ----
$("deleteAll").onclick = async () => {
  if (!state.proxies.length) return;
  state = await send({ cmd: "clearProxies" });
  render();
};

// ---- init ----
send({ cmd: "getState" }).then((s) => {
  state = s;
  clearForm();
  render();
});
