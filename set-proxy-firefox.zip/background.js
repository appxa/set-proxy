"use strict";

/*
 * State
 * -----
 * proxies:  [{ id, type: 'socks'|'http'|'https', host, port }]
 * activeId: string|null   -- which proxy in the list is selected
 * proxyOn:  bool          -- global switch; when true, route traffic
 *                            through the selected (activeId) proxy
 */

let proxies = [];
let activeId = null;
let proxyOn = false;
// In-memory only: survives popup closes, disappears with Firefox/background shutdown.
let pingResults = {};

browser.storage.local
  .get(["proxies", "activeId", "proxyOn"])
  .then((res) => {
    proxies = res.proxies || [];
    activeId = res.activeId || null;
    proxyOn = !!res.proxyOn;
    updateBadge();
  });

function saveState() {
  return browser.storage.local.set({ proxies, activeId, proxyOn });
}

function updateBadge() {
  const active = proxyOn && !!activeId;
  const state = active ? "on" : "off";
  browser.browserAction.setIcon({
    path: {
      16: `icons/icon-${state}-16.png`,
      32: `icons/icon-${state}-32.png`,
      48: `icons/icon-${state}-48.png`,
      96: `icons/icon-${state}-96.png`,
      128: `icons/icon-${state}-128.png`,
    },
  });
}

function activeProxy() {
  return proxies.find((p) => p.id === activeId) || null;
}

// ---- proxy info builder ----
function toProxyInfo(cfg) {
  if (cfg.type === "socks") {
    return { type: "socks", host: cfg.host, port: Number(cfg.port), proxyDNS: true };
  }
  return { type: cfg.type, host: cfg.host, port: Number(cfg.port) };
}

// ---- proxy routing ----
// (single listener: ad-hoc __proxytest requests take priority, then the
// active proxy, then direct)
const pendingTests = new Map();

browser.proxy.onRequest.addListener(
  (requestInfo) => {
    // ponytail: only parse URL when tests are pending — this listener
    // fires on every browser request, new URL() per call is wasteful
    if (pendingTests.size) {
      try {
        const u = new URL(requestInfo.url);
        const testId = u.searchParams.get("__proxytest");
        if (testId && pendingTests.has(testId)) {
          return toProxyInfo(pendingTests.get(testId));
        }
      } catch (e) {
        /* ignore */
      }
    }

    if (!proxyOn) return { type: "direct" };

    const cfg = activeProxy();
    if (!cfg) return { type: "direct" };

    if (!cfg.host || !cfg.port) return { type: "direct" };
    return toProxyInfo(cfg);
  },
  { urls: ["<all_urls>"] }
);

browser.proxy.onError.addListener((err) => {
  console.error("Proxy error:", err && err.message);
});

// ---- messages from popup ----
browser.runtime.onMessage.addListener(async (msg) => {
  switch (msg.cmd) {
    case "getState":
      return { proxies, activeId, proxyOn, pingResults };

    case "addProxy": {
      const cfg = msg.cfg;
      const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
      proxies.push({ id, ...cfg });
      if (!activeId) activeId = id; // first one added becomes selected
      await saveState();
      updateBadge();
      return { proxies, activeId, proxyOn, pingResults };
    }

    case "removeProxy": {
      proxies = proxies.filter((p) => p.id !== msg.id);
      if (activeId === msg.id) {
        activeId = proxies.length ? proxies[0].id : null;
      }
      await saveState();
      updateBadge();
      return { proxies, activeId, proxyOn, pingResults };
    }

    case "clearProxies": {
      proxies = [];
      activeId = null;
      await saveState();
      updateBadge();
      return { proxies, activeId, proxyOn, pingResults };
    }

    case "selectProxy":
      activeId = msg.id;
      await saveState();
      updateBadge();
      return { proxies, activeId, proxyOn, pingResults };

    case "setProxyOn":
      proxyOn = !!msg.on;
      await saveState();
      updateBadge();
      return { proxies, activeId, proxyOn, pingResults };

    case "testProxy": {
      const cfg = proxies.find((p) => p.id === msg.id);
      if (!cfg) return { ok: false, error: "not found" };
      try {
        const start = performance.now();
        if (!cfg.host || !cfg.port) return { ok: false, error: "host/port required" };
        // quick reachability probe through the configured proxy
        const testId = Date.now().toString(36) + Math.random().toString(36).slice(2);
        pendingTests.set(testId, cfg);
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 10000);
        try {
          const resp = await fetch("https://www.gstatic.com/generate_204?__proxytest=" + testId, {
            cache: "no-store",
            credentials: "omit",
            signal: ctrl.signal,
          });
          const ms = Math.round(performance.now() - start);
          const result = resp.ok || resp.status === 204
            ? { ok: true, ms }
            : { ok: false, error: "HTTP " + resp.status };
          pingResults[msg.id] = result;
          return result;
        } finally {
          clearTimeout(timer);
          pendingTests.delete(testId);
        }
      } catch (e) {
        const result = {
          ok: false,
          error: e.name === "AbortError" ? "timeout" : e.message || "unreachable",
        };
        pingResults[msg.id] = result;
        return result;
      }
    }

    case "testProxyCfg": {
      // test a raw {type,host,port} without adding to the list
      const cfg = msg.cfg;
      if (!cfg.host || !cfg.port) return { ok: false, error: "host/port required" };
      const testId = Date.now().toString(36) + Math.random().toString(36).slice(2);
      pendingTests.set(testId, cfg);
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 10000);
      try {
        const start = performance.now();
        const resp = await fetch(
          "https://www.gstatic.com/generate_204?__proxytest=" + testId,
          { cache: "no-store", credentials: "omit", signal: ctrl.signal }
        );
        const ms = Math.round(performance.now() - start);
        return resp.ok || resp.status === 204
          ? { ok: true, ms }
          : { ok: false, error: "HTTP " + resp.status };
      } catch (e) {
        return {
          ok: false,
          error: e.name === "AbortError" ? "timeout" : e.message || "unreachable",
        };
      } finally {
        clearTimeout(timer);
        pendingTests.delete(testId);
      }
    }

    case "addProxies": {
      // batch-add with dedup against existing list
      const existing = new Set(
        proxies.map((p) => p.type + ":" + p.host + ":" + p.port)
      );
      for (const cfg of msg.cfgs) {
        const key = cfg.type + ":" + cfg.host + ":" + cfg.port;
        if (existing.has(key)) continue;
        existing.add(key);
        const id =
          Date.now().toString(36) + Math.random().toString(36).slice(2);
        proxies.push({ id, ...cfg, country: cfg.country || null });
        if (cfg.ping) pingResults[id] = cfg.ping;
      }
      if (!activeId && proxies.length) activeId = proxies[0].id;
      await saveState();
      updateBadge();
      return { proxies, activeId, proxyOn, pingResults };
    }
  }
});
