"use strict";

/*
 * Chrome MV3 port of set-proxy.
 *
 * Chrome has no per-request proxy API (Firefox's proxy.onRequest).
 * chrome.proxy.settings is global/declarative — set once, applies to all.
 * So to TEST a proxy we temporarily set it as the global proxy, fetch, then
 * restore the previous state. This is the only reliable approach in Chrome.
 *
 * Uses mode:"fixed_servers" (not PAC script) — simpler, no eval, no caching
 * weirdness. scheme mapping: socks→"socks5", http→"http", https→"https".
 * SOCKS5 does remote DNS by default (matches Firefox proxyDNS:true).
 */

let proxies = [];
let activeId = null;
let proxyOn = false;

chrome.storage.local.get(["proxies", "activeId", "proxyOn"], (res) => {
  proxies = res.proxies || [];
  activeId = res.activeId || null;
  proxyOn = !!res.proxyOn;
  updateBadge();
  applyProxy();
});

function saveState() {
  return chrome.storage.local.set({ proxies, activeId, proxyOn });
}

function updateBadge() {
  const state = (proxyOn && !!activeId) ? "on" : "off";
  chrome.action.setIcon({
    path: {
      16: `icons/icon-${state}-16.png`,
      32: `icons/icon-${state}-32.png`,
      48: `icons/icon-${state}-48.png`,
      96: `icons/icon-${state}-96.png`,
      128: `icons/icon-${state}-128.png`,
    },
  });
}

function activeProxy() {
  return proxies.find((p) => p.id === activeId) || null;
}

function proxyScheme(type) {
  if (type === "socks") return "socks5";
  return type; // "http" or "https"
}

// ---- apply proxy settings to Chrome ----
// Returns a Promise that resolves after Chrome has applied the settings.
function setProxySettings(cfg) {
  return new Promise((resolve) => {
    if (!cfg || !cfg.host || !cfg.port) {
      chrome.proxy.settings.set(
        { value: { mode: "direct" }, scope: "regular" },
        () => setTimeout(resolve, 50)
      );
      return;
    }
    chrome.proxy.settings.set(
      {
        value: {
          mode: "fixed_servers",
          rules: {
            singleProxy: {
              scheme: proxyScheme(cfg.type),
              host: cfg.host,
              port: Number(cfg.port),
            },
          },
        },
        scope: "regular",
      },
      () => setTimeout(resolve, 50)
    );
  });
}

// Apply the current state (active proxy or direct)
function applyProxy() {
  if (proxyOn) {
    return setProxySettings(activeProxy());
  }
  return setProxySettings(null);
}

chrome.proxy.onProxyError.addListener(() => {});

// ---- messages from popup ----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMsg(msg)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, error: e.message || "error" }));
  return true;
});

async function handleMsg(msg) {
  switch (msg.cmd) {
    case "getState":
      return { proxies, activeId, proxyOn };

    case "addProxy": {
      const cfg = msg.cfg;
      const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
      proxies.push({ id, ...cfg });
      if (!activeId) activeId = id;
      await saveState();
      updateBadge();
      await applyProxy();
      return { proxies, activeId, proxyOn };
    }

    case "removeProxy": {
      proxies = proxies.filter((p) => p.id !== msg.id);
      if (activeId === msg.id) {
        activeId = proxies.length ? proxies[0].id : null;
      }
      await saveState();
      updateBadge();
      await applyProxy();
      return { proxies, activeId, proxyOn };
    }

    case "clearProxies":
      proxies = [];
      activeId = null;
      await saveState();
      updateBadge();
      await applyProxy();
      return { proxies, activeId, proxyOn };

    case "selectProxy":
      activeId = msg.id;
      await saveState();
      updateBadge();
      await applyProxy();
      return { proxies, activeId, proxyOn };

    case "setProxyOn":
      proxyOn = !!msg.on;
      await saveState();
      updateBadge();
      await applyProxy();
      return { proxies, activeId, proxyOn };

    case "testProxy": {
      const cfg = proxies.find((p) => p.id === msg.id);
      if (!cfg) return { ok: false, error: "not found" };
      return await runTestSerial(cfg);
    }

    case "testProxyCfg": {
      const cfg = msg.cfg;
      if (!cfg.host || !cfg.port) return { ok: false, error: "host/port required" };
      return await runTestSerial(cfg);
    }

    case "addProxies": {
      const existing = new Set(
        proxies.map((p) => p.type + ":" + p.host + ":" + p.port)
      );
      for (const cfg of msg.cfgs) {
        const key = cfg.type + ":" + cfg.host + ":" + cfg.port;
        if (existing.has(key)) continue;
        existing.add(key);
        const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
        proxies.push({ id, ...cfg });
      }
      if (!activeId && proxies.length) activeId = proxies[0].id;
      await saveState();
      updateBadge();
      await applyProxy();
      return { proxies, activeId, proxyOn };
    }
  }
}

// ---- test runner ----
// Chrome's proxy.settings is global — only one proxy at a time, so tests
// must run sequentially. To cut overhead we skip the restore between
// consecutive tests (the next test overwrites it anyway) and only restore
// once when the chain goes idle.
let testChain = Promise.resolve();
let restoreTimer = null;

function runTestSerial(cfg) {
  testChain = testChain.then(() => runTest(cfg));
  // Deferred restore: fires 300ms after the chain settles, cancelled if a
  // new test arrives before then.
  if (restoreTimer) clearTimeout(restoreTimer);
  restoreTimer = setTimeout(() => {
    restoreTimer = null;
    testChain = testChain.then(() => applyProxy());
  }, 300);
  return testChain;
}

async function runTest(cfg) {
  if (!cfg.host || !cfg.port) return { ok: false, error: "host/port required" };

  // Set the test proxy as the global proxy
  await setProxySettings(cfg);

  const start = performance.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 10000);
  try {
    const resp = await fetch("https://www.gstatic.com/generate_204", {
      cache: "no-store",
      credentials: "omit",
      signal: ctrl.signal,
    });
    const ms = Math.round(performance.now() - start);
    if (resp.ok || resp.status === 204) return { ok: true, ms };
    return { ok: false, error: "HTTP " + resp.status };
  } catch (e) {
    return {
      ok: false,
      error: e.name === "AbortError" ? "timeout" : e.message || "unreachable",
    };
  } finally {
    clearTimeout(timer);
    // No restore here — runTestSerial defers it so back-to-back tests
    // don't each pay the restore delay.
  }
}
